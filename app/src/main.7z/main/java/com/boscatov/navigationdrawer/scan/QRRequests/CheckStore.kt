package com.boscatov.navigationdrawer.scan.QRRequests

data class CheckStore(
        var checkStore: PriorityCheckQueue
)